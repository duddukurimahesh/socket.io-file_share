  var comparepassTo = function() {
      return {
          require: "ngModel",
          scope: {
              otherModelValue: "=comparepassTo"
          },
          link: function(scope, element, attributes, ngModel) {
              ngModel.$validators.comparepassTo = function(modelValue) {
                  return modelValue == scope.otherModelValue;
              };

              scope.$watch("otherModelValue", function() {
                  ngModel.$validate();
              });
          }
      };
  };

  Eleventhhour.directive("comparepassTo", comparepassTo);
