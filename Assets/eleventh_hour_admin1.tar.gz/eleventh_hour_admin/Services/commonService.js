Eleventhhour.factory("commonService", function($http, $timeout, $localStorage, $state, SweetAlert) {
    var admin = {};

    //********** url for web services ********//

    admin.baseUrl = "http://eleventhhourdev.ignivastaging.com:9051/v1/admin/";

    admin.getDetails = function(req, callback) {

        var req = {
            method: 'POST',
            url: admin.baseUrl + "AdminfetchingProfile",
            header: {
                'Content-Type': 'application/json'
            },


            data: req
        };

        $http(req).then(function(successCallback) {

            callback(null, successCallback.data)
        }, function(errorCallback) {
            //console.log('successCallback',successCallback)
            callback(null, errorCallback.data)
        });
    }

    admin.loader = function(status) {
        if (status == 'show')
            $("#loader").show();
        else if (status == 'hide')
            $("#loader").hide();
    }


    return admin;
});
