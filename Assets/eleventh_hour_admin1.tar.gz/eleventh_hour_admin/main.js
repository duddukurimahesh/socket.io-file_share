/*
 * Main app.js file
 */

console.log('++++++++++++++++++++++ Eleventh HOUR+++++++++++++++++++++++++');

var Eleventhhour = angular.module('Eleventhhour', ['oitozero.ngSweetAlert', 'ui.router', 'angular-jwt', 'ngStorage', 'ngFileUpload']);

Eleventhhour.config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise("/login");
    $stateProvider
        .state('login', {
            url: "/login",
            authenticate: false,
            templateUrl: "views/login.html"
        })

    .state('dashboard', {
        url: "/dashboard",
        authenticate: true,
        templateUrl: "views/dashboard.html"
    })

    .state('dashboard.dashboardList', {
        url: "/dashboardList",
        authenticate: true,
        templateUrl: "views/dashboardList.html"
    })

    .state('dashboard.changepassword', {
            url: "/changepassword",
            authenticate: true,
            templateUrl: "views/changepassword.html"
        })


    .state('dashboard.changeProfile', {
            url: "/changeProfile",
            authenticate: true,
            templateUrl: "views/changeProfile.html"
        })

    .state('dashboard.UserManagement', {
        url: "/ UserManagement",
        authenticate: true,
        templateUrl: "views/UserManagement.html"
    })


    .state('dashboard.addNewUser', {
        url: "/addNewUser",
        authenticate: true,
        templateUrl: "views/addNewUser.html"
    })


     .state('dashboard.EditUser', {
            url: "/EditUser/:User_id",
            authenticate: true,
            templateUrl: "views/EditUser.html"
        })

     .state('dashboard.DisputeManagement', {
            url: "/DisputeManagement",
            authenticate: true,
            templateUrl: "views/DisputeManagement.html"
        })
});

Eleventhhour.run(function($rootScope, $state, $localStorage, jwtHelper) {
    $rootScope.$on('$stateChangeStart',
        function(event, toState, toParams, fromState, fromParams, options) {
            if (toState.authenticate && !$localStorage.userDetails) {
                $state.go('login');
                event.preventDefault();
            }
        });
});
