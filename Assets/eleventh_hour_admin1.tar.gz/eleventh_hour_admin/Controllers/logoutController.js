Eleventhhour.controller('logoutController', function($scope, $http, $state, $localStorage, SweetAlert, jwtHelper, $timeout, commonService) {
    //************ logout service ************//
    $scope.logout = function() {
        //********** parameters for logout request ************//

        var req = {
            method: "POST",
            url: commonService.baseUrl + "AdminLogout",
            header: {
                'Content-Type': 'application/json'
            },
            data: {
                accessToken: $localStorage.userDetails.accessToken,
            }
        };


        //******* call loader true ***********//
        commonService.loader('show');
        //*************** call service for logout **********//
        $http(req).then(function(successCallback) {
            //******* call loader true ***********//
            commonService.loader('hide');
            if (successCallback.data.statusCode == 200) {
                //********** if logout success then call login page ***********//
               $localStorage.userDetails.accessToken = '';

                
                $state.go("login");

            }
        }, function(errorCallback) {
            //******* call loader true ***********//
            commonService.loader('hide');
            //************* for technical error ************//
            if (errorCallback.data.statusCode == 400) {

                SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000", "type": "warning" });
            } else if (errorCallback.data.statusCode == 401) {
                $localStorage.userDetails.accessToken = '';
                SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                $timeout(function() {
                    $state.go("login");
                }, 2000);

            }
        });
    }



});
