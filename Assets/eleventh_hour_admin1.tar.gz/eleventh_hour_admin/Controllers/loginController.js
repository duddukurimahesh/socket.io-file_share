Eleventhhour.controller('loginController', function($scope, $http, $state, $localStorage, SweetAlert, jwtHelper, $timeout, commonService) {
    //************ login service ************//
    $scope.login = function() {
        $scope.err_message = "";
        //********** parameters for login request ************//
        var req = {
            method: "POST",
            url: commonService.baseUrl + "AdminUserLogin",
            header: {
                'Content-Type': 'application/json'
            },
            data: {
                email: $scope.email,
                password: $scope.password
            }
        };
        console.log($scope.email);
        console.log($scope.password);

        //******* call loader true ***********//
        commonService.loader('show');
        //*************** call service for login **********//
        $http(req).then(function(successCallback) {
            //*********** call loader false ********//
            commonService.loader('hide');
            if (successCallback.data.statusCode == 200) {
                $localStorage.userDetails = successCallback.data.data.userDetails;
                $state.go("dashboard.UserManagement");
            }


        }, function(errorCallback) {
            //******* call loader true ***********//
            commonService.loader('hide');
            //*************8 for technical error ************//
            if (errorCallback.data.statusCode == 400) {
                //********** if credentials are incorrect ***********//
                $scope.err_message = errorCallback.data.message;
            }
        });
    }


    $scope.forgotpassword = function() {
        //******* call loader true ***********//


        $scope.email_msg = "";
        //********** parameters for submit code request ************//
        var req = {
            method: "POST",
            url: commonService.baseUrl + "AdminForgotPassword",
            header: {
                'Content-Type': 'application/json'
            },
            data: {
                email: $scope.forgot_email
            }
        };
        commonService.loader('show');
        //*************** call service for submit passcode **********//
        $http(req).then(function(successCallback) {
            //*********** call loader false ********//
            commonService.loader('hide');
            if (successCallback.data.statusCode == 200) {
                //********** if email id is correct then send link on email ***********//
                $("#forgotModal").modal('hide');
                SweetAlert.swal({ "title": successCallback.data.message, "timer": "3000" });
            }
        }, function(errorCallback) {
            //******* call loader true ***********//
            commonService.loader('hide');
            //************* for technical error ************//
            if (errorCallback.data.statusCode == 400) {
                //********** if credentials are incorrect ***********//
                $scope.email_msg = errorCallback.data.message;

            } else if (errorCallback.data.statusCode == 401) {
                $localStorage.userDetails.accessToken = '';
                SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                $timeout(function() {
                    $state.go("login");
                }, 2000);

            } else
                SweetAlert.swal({ "title": "Server not responding", "timer": "3000", "type": "error" });


        });
    }

});
