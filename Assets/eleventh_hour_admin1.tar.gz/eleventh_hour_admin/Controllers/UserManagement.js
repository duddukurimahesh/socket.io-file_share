Eleventhhour.controller('UserManagement', function($http, $scope, SweetAlert, Upload, $state, $localStorage, commonService, PagerService) {
    //*********** list of merchants **************//
    var vm = this;
    vm.pager = {};
    vm.setPage = setPage;
    vm.setPage(1);
    initController();
    $scope.index = 1;
    $scope.orderByField = 'fullName';
    $scope.reverseSort = false;


    function initController() {
        vm.setPage(1);
    }

    function setPage(page, limit) {
        if (page == 1)
            $scope.disableFirst = true;
        else
            $scope.disableFirst = false;

        var req = {
            method: "POST",
            url: commonService.baseUrl + "AdminfetchingAllUsers",
            header: {
                'Content-Type': 'application/json'
            },
            data: {

                limit: 10,
                skip: (page - 1) * 10

            }
        };

        commonService.loader('show');


        $http(req).then(function(successCallback) {

            commonService.loader('hide');

            if (successCallback.data.statusCode == 200) {

                vm.pager = PagerService.GetPager(successCallback.data.data, page);
                commonService.loader('hide');
                if (page == vm.pager.totalPages)
                    $scope.disableLast = true;
                else
                    $scope.disableLast = false;
                vm.start = vm.pager.startIndex;
                vm.orderList = successCallback.data.data.orderList;
                $scope.index = vm.pager.startIndex + 1;

            }
        }, function(errorCallback) {

            commonService.loader('hide');

            if (errorCallback.data.statusCode == 400) {
                SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000", "type": "error" });
            } else if (errorCallback.data.statusCode == 401) {
                $localStorage.userDetails.accessToken = '';
                SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                $timeout(function() {
                    $state.go("login");
                }, 2000);

            }
        });
    }

   $scope.suspendUser = function(User_id, status) {
        
      if (status == true){
             var user = "Inactive";
             var message = "Are you sure you want to InActive User?";
         }else{
             var user = "Active";
             var message = "Are you sure you want to Active User?";
         }
      

        SweetAlert.swal({
                title: message,
                text: "",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#DD6B55',
                confirmButtonText: 'Yes',
                cancelButtonText: "No",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function(isConfirm) {
                if (isConfirm) {
                    
                    var req = {
                        method: 'POST',
                        url: commonService.baseUrl + "AdminSuspendingUser",
                        header: {
                            'Content-Type': 'application/json'
                        },
                        data: {
                            accessToken: $localStorage.userDetails.accessToken,
                            userId: User_id,
                            userStatus: user
                        }
                    };

                   
                    commonService.loader('show');

                  
                    $http(req).then(function(successCallback) {
                        
                        commonService.loader('hide');
                      
                         if (successCallback.data.statusCode == 200) {
                            if (status)
                                SweetAlert.swal({ "title": "User  InActive successfully", "timer": "3000", type: "success" });
                            else
                                SweetAlert.swal({ "title": "User Active successfully", "timer": "3000", type: "success" });
                        }
                    }, function(errorCallback) {
                       
                        commonService.loader('hide');
                        if (errorCallback.data.statusCode == 400) {
                            SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000", "type": "error" });
                        } else if (errorCallback.data.statusCode == 1000)
                            return commonService.expire();
                    });
                } else {
                    setPage(vm.pager.currentPage);
                    swal("Cancelled", "", "error");
                }
            });

    }

});
