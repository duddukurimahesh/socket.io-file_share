Eleventhhour.controller('EditUser', function($http, $scope, SweetAlert, Upload, $state, $localStorage, commonService, PagerService) {
    console.log('Inside edit controller');
    console.log($state.params);

    (function() {
        var req = {

            method: 'POST',
            url: commonService.baseUrl + 'AdminfetchingUserDetails',
            header: {
                'Content-Type': 'application/json'
            },
            data: {

                userId: $state.params.User_id

            }
        };

        commonService.loader('show');
        $http(req).then(function(successCallback) {
            commonService.loader('hide');
            if (successCallback.data.statusCode == 200) {
                $scope.mail = successCallback.data.data.userDetails.email,
                $scope.f_name = successCallback.data.data.userDetails.fullName
            }

        }, function(errorCallback) {

            commonService.loader('hide');
            if (errorCallback.data.statusCode == 400) {

                SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000", "type": "warning" });
            } else if (errorCallback.data.statusCode == 401) {
                $localStorage.userDetails.accessToken = '';
                SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                $timeout(function() {
                    $state.go("login");
                }, 2000);
            }

        });
    })();

    $scope.EditUser = function() {

        var req = {

            method: 'POST',
            url: commonService.baseUrl + 'AdminEditingUsersProfile',
            header: {
                'Content-Type': 'application/json'
            },
            data: {
                accessToken: $localStorage.userDetails.accessToken,
                userId: $state.params.User_id,
                fullName: $scope.f_name,
                email: $scope.mail
            }
        };

        commonService.loader('show');
        $http(req).then(function(successCallback) {
            commonService.loader('hide');
            if (successCallback.data.statusCode == 200) {
                $scope.mail = successCallback.data.data.email,
                    $scope.f_name = successCallback.data.data.fullName
                SweetAlert.swal({ "title": "User Updated Sucessfully", "timer": "3000", "type": "success" });
                $state.go("dashboard.UserManagement");
            }

        }, function(errorCallback) {

            commonService.loader('hide');
            if (errorCallback.data.statusCode == 400) {

                SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000", "type": "warning" });
            } else if (errorCallback.data.statusCode == 401) {
                $localStorage.userDetails.accessToken = '';
                SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                $timeout(function() {
                    $state.go("login");
                }, 2000);

            }
        });
     }
});
