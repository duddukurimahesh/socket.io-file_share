Eleventhhour.controller('addNewUser', function($scope, $http, $state, $localStorage, SweetAlert, jwtHelper, $timeout, commonService) {

    $scope.AddUser = function() {

        var req = {

            method: 'POST',
            url: commonService.baseUrl + 'AdminAddingNewUser',
            header: {
                'Content-Type': 'application/json'
            },
            data: {

                fullName: $scope.f_name,
                email: $scope.Email,
                password: $scope.formData.password
            }
        };

        commonService.loader('show');
        $http(req).then(function(successCallback) {
            commonService.loader('hide');
            if (successCallback.data.statusCode == 200) {
                SweetAlert.swal({ "title": "User Added Sucessfully", "timer": "3000", "type": "success" });
                 $state.go("dashboard.UserManagement");
            }

        }, function(errorCallback) {

            commonService.loader('hide');
            if (errorCallback.data.statusCode == 400) {

                SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000" ,"type": "warning" });
            } else if (errorCallback.data.statusCode == 401) {
                $localStorage.userDetails.accessToken = '';
                SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                $timeout(function() {
                    $state.go("login");
                }, 2000);

            }
        });

    }

});
