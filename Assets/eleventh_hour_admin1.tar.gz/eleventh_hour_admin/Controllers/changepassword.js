Eleventhhour.controller('changepassword', function($scope, $http, $state, $localStorage, SweetAlert, jwtHelper, $timeout, commonService) {
    //************ login service ************//

    $scope.ChnagePass = function() {
        $scope.msgg = "";
        var req = {
            method: 'POST',
            url: commonService.baseUrl + "AdminChangePassword",
            header: {
                'Content-Type': 'application/json'
            },
            data: {
                accessToken: $localStorage.userDetails.accessToken,
                oldPassword: $scope.formData.oldpassword,
                newPassword: $scope.formData.password_c
            }
        };
        console.log($scope.msgg);
        //******* call loader true ***********//
        commonService.loader('show');
        if ($scope.formData.oldpassword != $scope.formData.password_c) {

            $http(req).then(function(successCallback) {
                //*********** call loader false ********//

                commonService.loader('hide');
                if (successCallback.data.statusCode == 200) {
                    $scope.msgg = '';
                    $localStorage.userDetails.accessToken = '';
                    $localStorage.userDetails._id = '';
                    SweetAlert.swal({ "title": "Password Changed Successfully", "timer": "2000" });
                    $timeout(function() {
                        $state.go("login");
                    }, 3000);
                }
            }, function(errorCallback) {
                //******* call loader true ***********//
                commonService.loader('hide');
                if (errorCallback.data.statusCode == 400) {

                    SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000" });
                } else if (errorCallback.data.statusCode == 401) {
                    $localStorage.userDetails.accessToken = '';
                    SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                    $timeout(function() {
                        $state.go("login");
                    }, 2000);

                }
            });
        } else {
            commonService.loader('hide');
            $scope.message = "Old and new password should not be same"
        }
    }
});
