Eleventhhour.controller('dashboardList', function($scope, $http, $state, $localStorage, SweetAlert, jwtHelper, $timeout, commonService, Upload) {
    //************ dashboardList service ************//


    $scope.BasePath = "http://eleventhhourdev.ignivastaging.com:9051/attachment/";
    $scope.fullName = $localStorage.userDetails.fullName;
    $scope.email = $localStorage.userDetails.email;
    $scope.url = $scope.BasePath + $localStorage.userDetails.profileImage;

    var req = {
        accessToken: $localStorage.userDetails.accessToken
    }
    commonService.getDetails(req, function(err, resp) {
        if (err) {
            SweetAlert.swal({ "title": successCallback.data.message, "timer": "3000" });
        } else {
            $scope.fullName = resp.data.userDetails.fullName;
            $scope.email = resp.data.userDetails.email;
            $scope.picFile = resp.data.userDetails.profileImage
        console.log("Resphjjjjonseeeee", resp.data.userDetails.profileImage);

         console.log('successCallback',resp);

        }
    })


    $scope.Adminprofile = function() {

        var req = {
            method: 'POST',
            url: commonService.baseUrl + "AdminUpdateProfile",
            header: {
                'Content-Type': 'application/json'
            },
            data: {
                accessToken: $localStorage.userDetails.accessToken,
                fullName: $scope.fullName,
                email: $scope.email
            }
        };
        commonService.loader('show');

        $http(req).then(function(successCallback) {
                commonService.loader('hide');
                if (successCallback.data.statusCode == 200) {
                    SweetAlert.swal({ "title": successCallback.data.message, "timer": "3000" });

                }

            },
            function(errorCallback) {

                commonService.loader('hide');
                if (errorCallback.data.statusCode == 400) {

                    SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000" });
                } else if (errorCallback.data.statusCode == 401) {
                    $localStorage.userDetails.accessToken = '';
                    SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                    $timeout(function() {
                        $state.go("login");
                    }, 2000);

                }

            });
    }


    $scope.uploadpic = function(file) {

       console.log("upload pic",$scope.picFile);
        if ($scope.picFile) {
            var data = {
                accessToken: $localStorage.userDetails.accessToken,
                profileImage: $scope.picFile
            }
            Upload.upload({
                method: 'POST',
                url: commonService.baseUrl + "AdminUploadProfileImage",
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
                data: data

            }).then(function(successCallback) {
                //******* call loader true ***********//
                commonService.loader('hide');
                console.log(successCallback);
                if (successCallback.data.statusCode == 200) {
                    SweetAlert.swal({ "title": "Profile Image updated Sucessfully", type: 'success', "timer": 3000 });

                }

            }, function(errorCallback) {

                commonService.loader('hide');
                if (errorCallback.data.statusCode == 400) {

                    SweetAlert.swal({ "title": errorCallback.data.message, "timer": "3000" });
                } else if (errorCallback.data.statusCode == 401) {
                    $localStorage.userDetails.accessToken = '';
                    SweetAlert.swal({ "title": "Session Expired", "timer": "2000" });
                    $timeout(function() {
                        $state.go("login");
                    }, 2000);

                }

            });
        }

    }

});
